package service;

import bean.BankBean;
import dao.BankDao;
import dao.BankDaoI;
import exceptions.*;

public class BankService implements BankServiceI {

	BankDaoI dao = new BankDao();
	BankBean bank = new BankBean();
	BankBean bank1 = new BankBean();

	boolean result;

	/*
	 * To get the details if account exists or not and add account
	 */
	public boolean createAccount(String name, String address, long accNo, String phone, int pin, int balance)
			throws AccountAlreadyExistsException {

		BankBean bean = new BankBean();
		boolean result = false;

		if (dao.checkAccount(accNo) == null) {
			bean.setAccNo(accNo);
			bean.setAdd(address);
			bean.setBalance(balance);
			bean.setName(name);
			bean.setPhone(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + balance + "\n");
			dao.setData(accNo, bean);
			result = true;
		} else {
			result = false;
			throw new AccountAlreadyExistsException();
		}
		return result;
	}

	/*
	 * Show Balance
	 */
	public int showBalance(long accNo) throws AccountNotFoundException {
		bank = dao.checkAccount(accNo);
		int balance = 0;
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			balance = bank.getBalance();
		}
		return balance;
	}

	/*
	 * Deposit
	 */
	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException {
		int balance = 0;
		bank = dao.checkAccount(accNo);
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			balance = bank.setBalance(bank.getBalance() + deposit_amount);
			String s = bank.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bank.setTrans(s);
			dao.setData(accNo, bank);
		}
		return balance;
	}

	/*
	 * Withdraw
	 */
	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, LowBalanceException {
		int balance = 0;
		bank = dao.checkAccount(accNo);
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			if (bank.getBalance() > withdraw_amount) {
				balance = bank.setBalance(bank.getBalance() - withdraw_amount);
				String s = bank.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bank.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			dao.setData(accNo, bank);
		}
		return balance;
	}

	/*
	 * Funds Transfer
	 */
	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException {
		bank = dao.checkAccount(accNo);
		if (!(bank == null)) {
			bank1 = dao.checkAccount(accNo1);
			if (!(bank1 == null)) {
				int sender_balance = bank.getBalance();
				if (sender_balance > transfer_amount) {
					int reciever_balance = bank1.getBalance();
					bank.setBalance(sender_balance - transfer_amount);
					bank1.setBalance(reciever_balance + transfer_amount);
					String s = bank.getTrans() + "Transferred to  :" + accNo1 + " Amount : " + transfer_amount + "\n";
					bank.setTrans(s);
					String s1 = bank1.getTrans() + "Transferred from  :" + accNo + " Amount : " + transfer_amount
							+ "\n";
					bank1.setTrans(s1);
					dao.setData(accNo, bank);
					dao.setData(accNo1, bank1);
				} else {
					throw new LowBalanceException();
				}
			} else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}
		return true;
	}

	/*
	 * Balance Validation
	 */
	public boolean validateBalance(long accNo, int amount) throws LowBalanceException {
		bank = dao.checkAccount(accNo);
		if (bank == null) {
			throw new LowBalanceException();
		} else {
			return true;
		}
	}

	/*
	 * Set Transaction
	 */
	public String setTrans(long accNo) throws AccountNotFoundException {
		bank = dao.checkAccount(accNo);
		String transaction;
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			transaction = bank.getTrans();
		}
		return transaction;
	}
}