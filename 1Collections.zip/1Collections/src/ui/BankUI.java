package ui;

import java.util.Scanner;

import exceptions.*;
import service.BankService;
import service.BankServiceI;
/*
 * 
 * Author : Mandeep Singh
   Id: 190107
 */
public class BankUI {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException {

		long accNo, accNo1;
		int withdrawAmount, depositAmount = 0, transferAmount = 0;
		int pin, amount = 0, balance = 0;
		boolean result = false;
		String proceed = "yes";

		BankServiceI service = new BankService();

		// To ask choice from users and perform operations
		while (proceed.equalsIgnoreCase("yes")) {
			switch (menu()) {

			/*
			 * Case to Create Account
			 */
			case 1:

				System.out.print("Enter name: ");
				String name = scanner.nextLine();
				name += scanner.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.print("Enter name: ");
					name = scanner.next();
				}

				System.out.print("Enter address: ");
				String add = scanner.next();
				add += scanner.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.print("Enter address: ");
					add = scanner.nextLine();
				}

				System.out.print("Enter phone number: ");
				String phone = scanner.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {
						System.out.println("Phone number should be of 10 digits");
						System.out.print("Enter phone number: ");
						phone = scanner.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.print("Enter phone number: ");
					phone = scanner.next();
				}

				accNo = (long) (Math.random() * 10000000);

				System.out.print("Enter PIN: ");
				pin = scanner.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {
					System.out.println("Pin number should be 0f 4 digits");
					System.out.print("Enter PIN: ");
					pin = scanner.nextInt();
				}

				System.out.print("Enter Balance: ");
				int bal = scanner.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.print("Enter Balance: ");
					bal = scanner.nextInt();
				}
				try {
					result = service.createAccount(name, add, accNo, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {
					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number: " + accNo);

				} else {
					System.out.println("Cannot Create Account");
				}
				break;

			/*
			 * Case to show Balance
			 */
			case 2:
				System.out.print("Enter account number: ");
				accNo = scanner.nextLong();
				try {
					balance = service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}
				System.out.print("Balance:" + balance);
				break;

			/*
			 * Case to Deposit Money
			 */
			case 3:
				System.out.print("Enter account no: ");
				accNo = scanner.nextLong();
				System.out.print("Enter amount to be deposited: ");
				depositAmount = scanner.nextInt();
				try {
					amount = service.deposit(accNo, depositAmount);
					balance = service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}
				System.out.print("Amount Deposited: " + depositAmount);
				System.out.print("Updated Balance: " + balance);
				break;

			/*
			 * Case to Withdraw Money
			 */
			case 4:

				System.out.print("Enter account no: ");
				accNo = scanner.nextLong();

				System.out.print("Enter amount to withdraw: ");
				withdrawAmount = scanner.nextInt();

				try {
					amount = service.withdraw(accNo, withdrawAmount);
					result = service.validateBalance(accNo, withdrawAmount);
					balance = service.showBalance(accNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}
				System.out.println("Amount Withdrawn: " + withdrawAmount);
				System.out.println("Updated Balance: " + balance);
				break;

			/*
			 * Case to Transfer Funds
			 */
			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.print("Enter account no: ");
				accNo = scanner.nextLong();

				System.out.print("Enter account to which you want to transfer fund: ");
				accNo1 = scanner.nextLong();

				System.out.print("Enter amount to transfer: ");
				transferAmount = scanner.nextInt();

				try {
					result = service.validateBalance(accNo, transferAmount);
					result = service.transferfund(accNo, accNo1, transferAmount);

					senders_balance = service.showBalance(accNo);
					recievers_balance = service.showBalance(accNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Updated balance for Account " + accNo + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accNo1 + " : " + recievers_balance);
				break;

			/*
			 * Case to Transfer Funds
			 */
			case 6:

				String s = null;
				System.out.print("Enter account number: ");
				accNo = scanner.nextLong();
				System.out.print("Enter PIN: ");
				pin = scanner.nextInt();
				try {
					s = service.setTrans(accNo);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				/*
				 * Case to Exit
				 */
			case 7:
				System.exit(0);
				proceed = "no";
				break;

			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();
			}
		}
	}

	// to display menu
	public static int menu() {
		System.out.println();
		 System.out.println("\n");
		   System.out.println("*********************** E-Wallet Menu ***********************");
		    System.out.print("|1.Create Account|            ");
		    System.out.print("|2.Show Balance|            ");
		    System.out.println("\n");
		    System.out.print("|3.Deposit|                   ");
		    System.out.print("|4.Withdraw|            ");
		    System.out.println("\n");
		    System.out.print("|5.Fund Transfer|             ");
		    System.out.print("|6.Print Transaction|            ");
		    System.out.println("\n");
		System.out.print("Enter Choice: ");
		int choice = scanner.nextInt();

		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Choice");
			System.out.print("Enter Choice: ");
			choice = scanner.nextInt();
		}
		return choice;
	}
}