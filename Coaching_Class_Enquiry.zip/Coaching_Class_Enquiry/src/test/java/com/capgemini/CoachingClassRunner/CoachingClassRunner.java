package com.capgemini.CoachingClassRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions( features= {"C:\\Amber\\Module4Exam\\186703_Coaching\\src\\test\\resources\\Coaching\\coaching.feature"},
  glue = "com.capgemini.CoachingClassStepDefination")
public class CoachingClassRunner {

}
