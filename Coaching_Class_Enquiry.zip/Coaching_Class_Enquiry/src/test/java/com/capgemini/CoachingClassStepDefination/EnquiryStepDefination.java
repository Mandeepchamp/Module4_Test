package com.capgemini.CoachingClassStepDefination;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.CoachingClassPageFactory.CoachingPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * 
 * @author ambpraka
 * @version 1.0 StepDefination class to Perform Automated Testing
 *
 */
public class EnquiryStepDefination {
	// Class members
	private WebDriver driver;
	private CoachingPageFactory coachingFactory;

	@Before // setup method to prepare and load the driver
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Amber\\Module4Exam\\186703_Coaching\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();
	}

	@Given("^user is on 'CoachingClass' page$")
	public void user_is_on_CoachingClass_page() throws Throwable {
		Thread.sleep(15000);
		driver.get("C:\\Amber\\Module4Exam\\186703_Coaching\\Coaching_Class_Enquiry.html");
		coachingFactory = new CoachingPageFactory(driver);
	}

	@When("^page is loaded$")
	public void page_is_loaded() throws Throwable {

	}

	/**
	 * 
	 * @throws Throwable Method to check if title is same or not
	 */
	@Then("^check if title of the page is 'Online Coaching Class Enquiry Form'$")
	public void check_if_title_of_the_page_is_Online_Coaching_Class_Enquiry_Form() throws Throwable {
		String expectedTitle = "Online Coaching Class Enquiry Form";
		String realTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, realTitle);
	}

	/**
	 * 
	 * @throws Throwable Method to check if text is present or not in title
	 */
	@Then("^check if there is a text 'Tuition Enquiry Details Form' in the title$")
	public void check_if_there_is_a_text_Tuition_Enquiry_Details_Form_in_the_title() throws Throwable {
		String expectedText = "Tuition Enquiry Details Form";
		boolean realResult = driver.getPageSource().contains(expectedText);
		Assert.assertEquals(true, realResult);
		driver.close();
	}

	/**
	 * 
	 * @throws Throwable Method to set FirstName
	 */
	@When("^user no data is entered in first name$")
	public void user_no_data_is_entered_in_first_name() throws Throwable {
		coachingFactory.setFirstName("");
		coachingFactory.setSubmitButton();
	}

	/**
	 * 
	 * @throws Throwable Method to check First Name is filled out or not
	 */
	@Then("^displays 'First Name must be filled out'$")
	public void displays_First_Name_must_be_filled_out() throws Throwable {
		String expectedText = "First Name must be filled out";
		String realText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, realText);
		driver.close();
	}

	/**
	 * 
	 * @throws Throwable Method to set LastName
	 */
	@When("^user no data is entered in last name$")
	public void user_no_data_is_entered_in_last_name() throws Throwable {
		coachingFactory.setLastName("");
		coachingFactory.setSubmitButton();
	}

	/**
	 * 
	 * @throws Throwable Method to check Last Name is filled out or not
	 */
	@Then("^displays 'Last Name must be filled out'$")
	public void displays_Last_Name_must_be_filled_out() throws Throwable {
		String expectedText = "Last Name must be filled out";
		String realText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, realText);
		driver.close();
	}

	/**
	 * 
	 * @throws Throwable Method to set the Email
	 */
	@When("^enters email$")
	public void enters_email() throws Throwable {
		coachingFactory.setEmail("ambarrai7@gmail.com");
	}

	/**
	 * 
	 * @throws Throwable Method to enter characters in Mobile field
	 */
	@When("^character data entered in the Mobile textbox$")
	public void character_data_entered_in_the_Mobile_textbox() throws Throwable {
		coachingFactory.setMobile("qwerty");
		coachingFactory.setSubmitButton();
	}

	/**
	 * 
	 * @throws Throwable Method to show alert "Enter numeric value" for Mobile
	 */
	@Then("^displays the message 'Enter numeric value'$")
	public void displays_the_message_Enter_numeric_value() throws Throwable {
		String expectedText = "Enter numeric value";
		String realText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, realText);
		driver.close();
	}

	/**
	 * 
	 * @throws Throwable Method to enter invalid mobile number in Mobile field
	 * 
	 */

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		coachingFactory.setMobile("123456");
		coachingFactory.setSubmitButton();
	}

	/**
	 * 
	 * @throws Throwable Method to show alert "Enter 10 digit mobile number" for
	 *                   Mobile
	 */

	@Then("^displays 'Enter (\\d+) digit mobile number'$")
	public void displays_Enter_digit_mobile_number(int no) throws Throwable {
		String expectedText = "Enter " + no + " digit Mobile number";
		String realText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, realText);
		driver.close();
	}

	/**
	 * 
	 * @throws Throwable Method to set Tution as Spoken English
	 */
	@When("^tution required selected as 'Spoken English'$")
	public void tution_required_selected_as_Spoken_English() throws Throwable {
		coachingFactory.settution("Spoken English");
	}

	/**
	 * 
	 * @throws Throwable Method to set city as Pune
	 */
	@When("^select city preference as 'Pune'$")
	public void select_city_preference_as_Pune() throws Throwable {
		coachingFactory.setCity("Pune");
	}

	/**
	 * 
	 * @throws Throwable Method to set mode as Class rooom training
	 */
	@When("^select Mode of Learning as 'Class Room training'$")
	public void select_Mode_of_Learning_as_Class_Room_training() throws Throwable {
		coachingFactory.setMode("Class rooom training");
	}

	/**
	 * 
	 * @throws Throwable Method to submit the data
	 */
	@When("^submit the request button$")
	public void submit_the_request_button() throws Throwable {
		coachingFactory.setSubmitButton();
	}

	/**
	 * 
	 * @throws Throwable Method to verify that Enquiry details is filled out or not
	 */
	@Then("^Verify the alert box displays message 'Enquiry details must be filled out'$")
	public void verify_the_alert_box_displays_message_Enquiry_details_must_be_filled_out() throws Throwable {
		String expectedText = "Enquiry details must be filled out";
		String realText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		Assert.assertEquals(expectedText, realText);
		driver.close();
	}

	/**
	 * 
	 * @throws Throwable Method to verify that all details are filled out
	 */

	@When("^user enters valid enquiry details$")
	public void user_enters_valid_enquiry_details() throws Throwable {
		coachingFactory.setFirstName("Amber");
		coachingFactory.setLastName("Rai");
		coachingFactory.setEmail("ambarrai7@gmail.com");
		coachingFactory.setMobile("9515766055");
		coachingFactory.settution("Spoken English");
		coachingFactory.setCity("Pune");
		coachingFactory.setMode("Class rooom training");
		coachingFactory.setEnquiry("This is an sample text entered by Amber ");
		coachingFactory.setSubmitButton();
	}

	/**
	 * 
	 * @throws Throwable Method to verify the Thank you message
	 */
	@Then("^Verify the message 'Thank you for submitting the online coaching Class Enquiry'$")
	public void verify_the_message_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {
		String expectedText = "Thank you for submitting the online coaching Class Enquiry";
		String actualText = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedText, actualText);
	}

	/**
	 * 
	 * @throws Throwable Method to click on OK Button
	 */
	@Then("^Click OK$")
	public void click_OK() throws Throwable {
		driver.switchTo().alert().accept();
	}

	/**
	 * 
	 * @throws Throwable Method to verify the message Our Counselor will contact you
	 *                   soon
	 */
	@Then("^Verify the text 'Our Counselor will contact you soon' after submission of form$")
	public void verify_the_text_Our_Counselor_will_contact_you_soon_after_submission_of_form() throws Throwable {
		String expectedText = "Our Counselor will contact you soon.";
		String actualText = driver.findElement(By.tagName("h3")).getText();
		Assert.assertEquals(expectedText, actualText);
	}

	/**
	 * 
	 * @throws Throwable Method to close the browse the window
	 */
	@Then("^Close the browser window$")
	public void close_the_browser_window() throws Throwable {
		driver.quit();
	}

}
