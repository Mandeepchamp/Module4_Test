package com.capgi.featuredefinition;

public class FeatureDefinition {

}
