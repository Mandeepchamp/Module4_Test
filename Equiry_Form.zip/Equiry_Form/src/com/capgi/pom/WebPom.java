package com.capgi.pom;

public class WebPom {

}
