package com.capgi.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions( features= {"C:\\Mandeep\\BDD_LAB\\Coaching_Enquiry\\src\\feature\\coaching.feature"},
  glue = "CoachingClassStepDefination")
public class Runner {

}
