package JobBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
/*
 * Author: Mandeep Singh(190107)
 */
public class JobRegistrationPageFactory {
	WebDriver driver;
	
	@FindBy(id="usrID")
	@CacheLookup
	WebElement userId;


	//using how class
	@FindBy(how=How.NAME, using="submit")
	@CacheLookup
	WebElement confirmButton;

	
	@FindBy(how=How.ID, using="pwd")
	@CacheLookup
	WebElement password;

	@FindBy(how=How.ID, using="usrname")
	@CacheLookup
	WebElement userName;

	
	@FindBy(how=How.NAME, using="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(how=How.NAME, using="country")
	@CacheLookup
	WebElement country;

	@FindBy(how=How.NAME, using="zip")
	@CacheLookup
	WebElement zipCode;
	
	@FindBy(how=How.NAME, using="email")
	@CacheLookup
	WebElement userEmail;
	
	@FindBy(how=How.NAME, using="sex")
	@CacheLookup
	WebElement gender;
	
	@FindBy(how=How.NAME, using="en")
	@CacheLookup
	WebElement language;
	
	@FindBy(how=How.ID, using="desc")
	@CacheLookup
	WebElement about;

	
	
	  //initiating Elements using Constructor
		public JobRegistrationPageFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	//Getter and setter
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}
	
	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton(WebElement confirmButton) {
		this.confirmButton.click();
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode.sendKeys(zipCode);
	}

	public WebElement getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail.sendKeys(userEmail);
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(WebElement gender) {
		this.gender = gender;
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage(WebElement language) {
		this.language = language;
	}

	public WebElement getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);
	}

	
	
}
