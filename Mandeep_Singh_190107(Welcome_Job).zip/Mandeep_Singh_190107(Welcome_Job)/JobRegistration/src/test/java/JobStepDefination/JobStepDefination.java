package JobStepDefination;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import JobBean.JobRegistrationPageFactory;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
/*
 * Author: Mandeep Singh(190107)
 */
public class JobStepDefination {
	private WebDriver driver;
	private JobRegistrationPageFactory jobFactory;
	
	// setup method to prepare and load the driver
	@Before 
	public void setUp() {
		
				 String path = "driver\\chromedriver.exe";
	    System.setProperty("webdriver.chrome.driver",path );
	driver= new ChromeDriver();
	}

//Senario 1:
@Given("^user is on 'RegistrationForm' page$")
public void user_is_on_RegistrationForm_page() throws Throwable {
	
	driver.get("C:\\Mandeep\\BDD_LAB\\JobRegistration\\target\\RegistrationForm.html");
	jobFactory = new JobRegistrationPageFactory(driver);
}

@When("^page is loaded$")
public void page_is_loaded() throws Throwable {
  
}

@Then("^check if title of the page is 'Job Registration Form'$")
public void check_if_title_of_the_page_is_Job_Registration_Form() throws Throwable {
	String expectedTitle = "Welcome to JobsWorld";
	String realTitle = driver.getTitle();
	Assert.assertEquals(expectedTitle, realTitle);
	driver.close();
}

//Senario 2:
@When("^user no data is or not between (\\d+) to (\\d+) entered in User ID$")
public void user_no_data_is_or_not_between_to_entered_in_User_ID(int arg1, int arg2) throws Throwable {
	jobFactory.setUserId("23");
	jobFactory.getConfirmButton();
	
}

@Then("^displays 'User ID must be filled out'$")
public void displays_User_ID_must_be_filled_out() throws Throwable {
   
	driver.close();
}

//Senario 3:
@When("^user eneter data is entered in passward$")
public void user_eneter_data_is_entered_in_passward() throws Throwable {
	jobFactory.setPassword("7896");
	jobFactory.getConfirmButton();
}

@Then("^displays 'Password must be filled out'$")
public void displays_Password_must_be_filled_out() throws Throwable {
	driver.close();
}

//Senario 4:
@When("^character data entered in the Name field$")
public void character_data_entered_in_the_Name_field() throws Throwable {
	jobFactory.setUserName("");
	jobFactory.getConfirmButton();
}

@Then("^displays the message 'Name must be filled out'$")
public void displays_the_message_Name_must_be_filled_out() throws Throwable {
	//driver.switchTo().alert().accept();
	driver.close();
}

//Senario 5:
@When("^user does not enter address$")
public void user_does_not_enter_address() throws Throwable {
	jobFactory.setAddress("");
	jobFactory.getConfirmButton();
}

@Then("^display 'Please Enter Address'$")
public void display_Please_Enter_Address() throws Throwable {
	//driver.switchTo().alert().accept();
	driver.close();
}

//Senario 6:
@When("^user enters invalid Country$")
public void user_enters_invalid_Country() throws Throwable {
	jobFactory.setCountry("");
	jobFactory.getConfirmButton();
}

@Then("^display 'Please fill Country'$")
public void display_Please_fill_Country() throws Throwable {
	driver.close();
}

//Senario 7:
@When("^user does not enter zip code$")
public void user_does_not_enter_zip_code() throws Throwable {
	jobFactory.setZipCode("");
}

@Then("^display 'Please Enter zip code'$")
public void display_Please_Enter_zip_code() throws Throwable {
	driver.close();
}

//Senario 8:
@When("^user does not enter Email$")
public void user_does_not_enter_Email() throws Throwable {
	jobFactory.setUserEmail("");
}

@Then("^display 'Please Enter email'$")
public void display_Please_Enter_email() throws Throwable {
	driver.close();
	
 

}

//Senario 9:
@When("^user enters valid details$")
public void user_enters_valid_details() throws Throwable {
	jobFactory.setUserId("100134");
	jobFactory.setPassword("23456789");
	jobFactory.setUserName("Mandeep");
	jobFactory.setAddress("Delhi");
	WebElement country=jobFactory.getCountry();
    Select se1=new Select(country);
      se1.selectByVisibleText("India");
      jobFactory.setZipCode("2345");
      jobFactory.setUserEmail("mandeep@gmail.com");
      WebElement gender = jobFactory.getGender();
      gender.click();
      jobFactory.setAbout("Information");
	
}

@Then("^Login succesfully$")
public void login_succesfully() throws Throwable {
	WebElement loginButton = jobFactory.getConfirmButton();
	Thread.sleep(500);
    loginButton.click();
	
	
}



}
