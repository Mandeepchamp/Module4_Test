package jobrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/*
 * Author: Mandeep Singh(190107)
 */
@RunWith(Cucumber.class)
@CucumberOptions( features= {"C:\\Mandeep\\BDD_LAB\\JobRegistration\\jobRegistration.feature"},
  glue = "JobStepDefination")
public class TestRunner {

}
